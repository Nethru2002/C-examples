//Write a c program to input an income and a cost and calculate profit or loss.

#include <stdio.h>
#include <stdlib.h>

int main()
{
    float income, cost, profit;

    printf("Enter your income: \n");
    scanf("%f", &income);

    printf("Enter your cost: \n");
    scanf("%f", &cost);

    profit=income-cost;

    if(profit>0)
    {
        printf("This is a profit.\n", profit);
    }

    else if(profit<0)
    {
        printf("This is a loss.\n", profit);
    }

    else
    {
        printf("This is not a profit or a loss.\n");
    }
    return 0;
}
