//Write a c program to check whether a number is even or odd using switch case.

#include <stdio.h>
#include <stdlib.h>

int main()
{
    int number;

    printf("Enter a number: \n");
    scanf("%d", &number);

    switch(number%2)
    {
    case 1:
        printf("%d is an even number.\n", number);
        break;

    case 2:
        printf("%d is an odd number.\n", number);
        break;

    default:
        printf("This is an invalid input. Please enter a valid number.\n");
        break;
    }

    return 0;
}
