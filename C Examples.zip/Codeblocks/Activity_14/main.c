//Write a c program is check whether this triangle is equilateral, isosceles or scalene.

#include <stdio.h>
#include <stdlib.h>

int main()
{
    float side1, side2, side3;

    printf("Enter the lengths of all sides of a triangle: \n");
    scanf("%f %f %f", &side1, &side2, &side3);

    if (side1==side2 && side2==side3)
    {
        printf("This is a equilateral triangle.\n");
    }

    else if (side1==side2 || side1==side3 || side2==side3);
    {
        printf("This is a isosceles triangle.\n");
    }

    else
    {
        printf("This is a scalene triangle.\n");
    }

    return 0;
}
