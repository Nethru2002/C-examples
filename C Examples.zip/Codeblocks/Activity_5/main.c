//Write a c program to check whether a number is even or odd. Only for even numbers display.

#include <stdio.h>
#include <stdlib.h>

int main()
{
    int number;

    printf("Enter a number: ");
    scanf("%d", &number);

    if(number%2==0)
    {
        printf("This number is an even number.\n", number);
    }
    return 0;
}
