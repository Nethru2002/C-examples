//Write a c program to check whether a year is leap year or not.

#include <stdio.h>
#include <stdlib.h>

int main()
{
    int year;

    printf("Enter an year: ");
    scanf("%d", &year);

    if(year%4==0)
    {
        printf("This is a leap year.\n", year);
    }

    else
    {
        printf("This is not a leap year.\n", year);
    }

    return 0;
}
