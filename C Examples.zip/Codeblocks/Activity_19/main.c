//Write a c program to print day of a week name using switch case.

#include <stdio.h>
#include <stdlib.h>

int main()
{
    int day;

    printf("Please enter a day number (1-7): \n");
    scanf("%d", &day);

    switch (day)
    {
    case 1:
        printf("Monday\n");
        break;

    case 2:
        printf("Tuesday\n");
        break;

    case 3:
        printf("Wednesday\n");
        break;

    case 4:
        printf("Thursday\n");
        break;

    case 5:
        printf("Friday\n");
        break;

    case 6:
        printf("Saturday\n");
        break;

    case 7:
        printf("Sunday\n");
        break;

    default:
        printf("This is an invalid day number. Please insert a valid day number.\n");
        break;
    }

    return 0;
}
