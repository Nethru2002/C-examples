//Write a c program to input any alphabet and check whether it is a vowel or a consonant.

#include <stdio.h>
#include <stdlib.h>

int main()
{
    char ch;

    printf("Enter a character: ");
    scanf("%d", &ch);

    if(ch>='a' && ch<='z')
    {
        if(ch=='a' || ch=='e' || ch=='i' || ch=='o' || ch=='u')
        {
            printf("This is a vowel.\n", ch);
        }
        else
        {
            printf("This is a consonant.\n", ch);
        }
        else
        {
            printf("This is not an alphabetical character. Please insert a valid alphabetical character.\n", ch );
        }
    }
    return 0;
}
