//Write a c program to check whether a number is negative, positive or zero.

#include <stdio.h>
#include <stdlib.h>

int main()
{
    int number;

    printf("Enter a number: ");
    scanf("%d", &number);

    if (number>0)
    {
        printf("This number is a positive number");
    }

    else if (number<0)
    {
        printf("This number is a negative number");
    }

    else
    {
        printf("This number is zero");
    }

    return 0;
}
