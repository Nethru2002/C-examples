//Write a c program to find maximum between three numbers.

#include <stdio.h>
#include <stdlib.h>

int findMaximum (int num1,int num2,int num3)
{
    int max=num1;

    if (num2>max)
    {
        max=num2;
    }

    if (num3>max)
    {
        max=num3;
    }
return max;
}

int main()
{
    int num1,num2,num3;
    printf("Enter three numbers: ");
    scanf("%d %d %d",&num1,&num2,&num3);
    int maximum=findMaximum (num1,num2,num3);
    printf("The maximum number is: %d\n",maximum);
    return 0;
}
