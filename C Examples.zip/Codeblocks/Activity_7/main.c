//Write a c program to check whether a character is alphabet or not.

#include <stdio.h>
#include <stdlib.h>

int main()
{
    char ch;

    printf("Enter a character: ");
    scanf("%c", &ch);

    if(ch>='a' && ch<='z' || ch>='A' && ch<='Z')
    {
        printf("This is an alphabetical character.\n", ch);
    }

    else
    {
        printf("This is not an alphabetical character.\n", ch);
    }
    return 0;
}
