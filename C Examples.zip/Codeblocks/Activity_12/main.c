//Write a c program to input month number and print number of days in that month.

#include <stdio.h>
#include <stdlib.h>

int main()
{
    int monthNumber;

    printf("Enter a month number: ");
    scanf("%d", &monthNumber);

    if(monthNumber>=1 && monthNumber<=12)
    {
        int days;

        if(monthNumber==2)
        {
            days=28;
        }

        if(monthNumber==1,monthNumber==3,monthNumber==5,monthNumber==7,monthNumber==8,monthNumber==10,monthNumber==12)
        {
            days=31;
        }

        if(monthNumber==4,monthNumber==6,monthNumber==9,monthNumber==11)
        {
            days=30;
        }

        printf("The number of days in %d month is %d\n", monthNumber, days);
    }

    else
    {
        printf("This is an invalid month number. Please insert a valid month number.\n");
    }

    return 0;
}
