#include <stdio.h>
#include <stdlib.h>

int main()
{
    char covidVaccine1, covidVaccine2, covidVaccine3;
    int age;
    float bloodPressure, sugarLevel;

    printf("If you got the first dose of covid vaccination ('Y' for yes and 'N' for no): \n");
    scanf("%c", &covidVaccine1);

    printf("If you got the second dose of covid vaccination ('Y' for yes and 'N' for no): \n");
    scanf("%c", &covidVaccine2);

    printf("If you got the third dose of covid vaccination ('Y' for yes and 'N' for no): \n");
    scanf("%c", &covidVaccine3);

    printf("Enter your age: \n");
    scanf("%d", &age);

    printf("Enter your blood pressure level: \n");
    scanf("%f", &bloodPressure);

    printf("Enter your sugar level: \n");
    scanf("%f", &sugarLevel);

    if(covidVaccine1='Y' && covidVaccine2='Y' && covidVaccine3='Y' && age>=50)
    {
        printf("You need to get your monkey pox vaccine.\n");
    }

    if(covidVaccine1='Y' && covidVaccine2='Y' && covidVaccine3='Y' && age<50)
    {
        printf("You don't need to get your monkey pox vaccine.\n");
    }

    if(covidVaccine1='Y' && covidVaccine2='Y' && covidVaccine3='N' && age>=50)
    {
        printf("You need to get your monkey pox vaccine.\n");
    }

    if(covidVaccine1='Y' && covidVaccine2='Y' && covidVaccine3='N' && age<50 && bloodPressure>=130 || sugarLevel>=120)
    {
        printf("You need to get your monkey pox vaccine.\n");
    }

    if(covidVaccine1='Y' && covidVaccine2='Y' && covidVaccine3='N' && age<50 && bloodPressure<130 && sugarLevel<120)
    {
        printf("You don't need to get your monkey pox vaccine.\n");
    }

    if(covidVaccine1='Y' && covidVaccine2='N' && covidVaccine3='N' && age>=50)
    {
        printf("You need to get your monkey pox vaccine.\n");
    }

    if(covidVaccine1='Y' && covidVaccine2='N' && covidVaccine3='N' && age<50 && bloodPressure>=130)
    {
        printf("You need to get your monkey pox vaccine.\n");
    }

    if(covidVaccine1='Y' && covidVaccine2='N' && covidVaccine3='N' && age<50 && bloodPressure<130)
    {
        printf("You don't need to get your monkey pox vaccine.\n");
    }

    if(covidVaccine1='N' && covidVaccine2='N' && covidVaccine3='N')
    {
        printf("You need to get your monkey pox vaccine.\n");
    }

    return 0;
}
