//Write a c program to check whether an alphabet is vowel or consonant using switch case.

#include <stdio.h>
#include <stdlib.h>

int main()
{
    char alphabet;

    printf("Enter an alphabetical character: \n");
    scanf("%c", &alphabet);

    switch (alphabet)
    {

    case 'a':
        printf("This is a vowel.\n");
        break;

    case 'e':
        printf("This is a vowel.\n");
        break;

    case 'i':
        printf("This is a vowel.\n");
        break;

    case 'o':
        printf("This is a vowel.\n");
        break;

    case 'u':
        printf("This is a vowel.\n");
        break;

    case 'A':
        printf("This is a vowel.\n");
        break;

    case 'E':
        printf("This is a vowel.\n");
        break;

    case 'I':
        printf("This is a vowel.\n");
        break;

    case 'O':
        printf("This is a vowel.\n");
        break;

    case 'U':
        printf("This is a vowel.\n");
        break;

    default:
        printf("This is a consonant.\n");
        break;
    }

    return 0;
}
