#include <stdio.h>
#include <stdlib.h>

int main()
{
    float basicSalary, allowance, tax, totalSalary;
    char designation;

    printf("Please enter your designation ('M' for manager, 'E' for executive and 'O' for other): \n");
    scanf("%c", &designation);

    printf("Please enter your basic salary: \n");
    scanf("%f", &basicSalary);

    printf("Please enter your total receivable allowance amount: \n");
    scanf("%f", &allowance);

    switch (designation)
    {
    case 'M':
        if (basicSalary>=200000)
        {
            tax=0.05;
        }
        else (basicSalary>=100000)
        {
            tax=0.03;
        }
        break;

    case 'E':
        if (basicSalary>=150000)
        {
            tax=0.03;
        }
        break;

    case 'O':
        tax=0.0;
        break;

    default:
        printf("This is an invalid designation. Please insert a valid designation.\n");

    return 1;
    }

    totalSalary=basicSalary+allowance-(basicSalary*tax);

    printf("Your total salary is: \n", totalSalary);

    return 0;
}
