//Write a c program to input any character and check whether it is an alphabet,digit or special character.

#include <stdio.h>
#include <stdlib.h>

int main()
{
    char ch;

    printf("Enter a character: ");
    scanf("%c", &ch);

    if(ch>='a' && ch<='z' || ch>='A' && ch<='Z')
    {
        printf("This is an alphabetical character.\n", ch);
    }

    else if(ch>='0' && ch<='9')
    {
        printf("This is a digit.\n", ch);
    }
    else
    {
        printf("This is a special character.\n", ch);
    }
    return 0;
}
