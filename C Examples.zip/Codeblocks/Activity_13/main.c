//Write a c program to input all sides of a triangle and check whether triangle is valid or not.

#include <stdio.h>
#include <stdlib.h>

int validTriangle(int side1, int side2, int side3)
{
    if(side1+side2>side3 && side1+side3>side2 && side2+side3>side1)
    {
        return 1;
    }

    else
    {
        return 0;
    }
}

int main()
{
    printf("Enter the lengths of all sides of the triangle: \n");

    printf("Enter the length of side 1: ");
    scanf("%d", &side1);

    printf("Enter the length of side 2: ");
    scanf("%d", &side2);

    printf("Enter the length of side 3: ");
    scanf("%d", &side3);

    if(validTriangle(side1, side2, side3))
    {
        printf("This is a valid triangle.\n");
    }

    else
    {
        printf("This is not a valid triangle.\n");
    }

return 0;
}
