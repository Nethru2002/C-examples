//Write a c program to input week number and print week day.

#include <stdio.h>
#include <stdlib.h>

int main()
{
    int weekNumber;

    printf("Enter a week number: ");
    scanf("%d", &weekNumber);

    switch (weekNumber)
    {
        case 1:
            printf("Monday.\n");
            break;
        case 2:
            printf("Tuesday.\n");
            break;
        case 3:
            printf("Wednesday.\n");
            break;
        case 4:
            printf("Thursday.\n");
            break;
        case 5:
            printf("Friday.\n");
            break;
        case 6:
            printf("Saturday.\n");
            break;
        case 7:
            printf("Sunday.\n");
            break;
        default:
            printf("This is not a valid week number. Please input a valid week number.\n");
            break;
    }
    return 0;
}
