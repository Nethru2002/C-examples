//Write a c program to check whether a number is divisible by 5 and 11.

#include <stdio.h>
#include <stdlib.h>

int main()
{
    int number;

    printf("Enter a number: ");
    scanf("%d", &number);

    if(number%5==0 && number%11==0)
    {
        printf("This number is divisible by 5 and 11.\n", number);
    }

    else
    {
        printf("This number is not divisible by 5 and 11.\n", number);
    }
    return 0;
}
