//Write a c program to check whether a character is uppercase or lowercase alphabet.

#include <stdio.h>
#include <stdlib.h>

int main()
{
    char ch;

    printf("Enter a character: ");
    scanf("%c", &ch);

    if(ch>='A' && ch<='Z')
    {
        printf("This is an uppercase alphabetical character.\n", ch);
    }

    if(ch>='a' && ch<='z')
    {
        printf("This is a lowercase alphabetical character.\n", ch);
    }

    return 0;
}
