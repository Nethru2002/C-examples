//Write a c program to find maximum between two numbers using switch case.

#include <stdio.h>
#include <stdlib.h>

int main()
{
    int number1, number2;

    printf("Enter the first number: \n");
    scanf("%d", &number1);

    printf("Enter the second number: \n");
    scanf("%d", &number2);

    if(number1>number2)
    {
        printf("First number is bigger than the second number.\n");
    }

    else
    {
        printf("Second number is bigger than the first number.\n");
    }

    return 0;
}
