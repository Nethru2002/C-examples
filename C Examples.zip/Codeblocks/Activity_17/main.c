#include <stdio.h>
#include <stdlib.h>

int main()
{
    float tax, discount, totalBill, cost;
    int numberOfUnits;

    printf("Enter the number of units used: \n");
    scanf("%d", &numberOfUnits);

    if (numberOfUnits>=500)
    {
        cost=numberOfUnits*50;
    }

    else if (numberOfUnits>=250)
    {
        cost=numberOfUnits*30;
    }

    else (numberOfUnits<250)
    {
        cost=numberOfUnits*20;
    }

    if (cost>=4500)
    {
        tax=cost*0.05;
    }

    if (cost>2000)
    {
        tax=cost*0.03;
    }

    if (cost<=500)
    {
        discount=cost*0.05;
    }

    if (cost<=1000)
    {
        discount=cost*0.03;
    }

    totalBill=(cost+tax)-discount;

    printf("Your total bill is: \n", totalBill);

    return 0;
}
