//Write a c program to read the marks of 3 subjects. If the total is greater than or equal 150, 3 marks will be added as bonus. You need to find and display total marks for students.

#include <stdio.h>
#include <stdlib.h>

int main()
{
    int marks1, marks2, marks3, total;

    printf("Enter the marks of subject 1: ");
    scanf("%d", &marks1);

    printf("Enter the marks of subject 2: ");
    scanf("%d", &marks2);

    printf("Enter the marks of subject 3: ");
    scanf("%d", &marks3);

    total=marks1+marks2+marks3;

    if (total>=150)
    {
        total+=3;
    }

    printf("Total marks: %d\n", total);

    return 0;
}
