//Write a c program to check whether a number is positive, negative or zero using switch case.

#include <stdio.h>
#include <stdlib.h>

int main()
{
    int number;

    printf("Enter a number: \n");
    scanf("%d", &number);

    switch(number>0)
    {
        case 1:
            printf("%d is a positive number.\n", number);
            break;

        case 2:
            switch(number<0)
            {
                case 1:
                    printf("%d is a negative number.\n", number);
                    break;

                case 2:
                    printf("%d is zero.\n", number);
                    break;
            }

        default:
            {
                printf("This is an invalid input. Please insert a valid number.\n");
                break;
            }
    }

    return 0;
}
